package org.com.output;

public class Outputclass {

}

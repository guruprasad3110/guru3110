package Simulations

import io.gatling.core.scenario.Simulation
import io.gatling.core.Predef._
import io.gatling.http.Predef._

class LoadTestAPISimulation extends Simulation{

  //http conf
  val httpconfig=http.baseUrl("https://reqres.in")
     .header("Accept","application/json")
//scenario
 val scn= scenario("getListofUsers")
    .exec(http("getrequestforListofUsers")
    .get("/api/users/2")
    .check(status is 200))

  //setup

  setUp(scn.inject(atOnceUsers(10))).protocols(httpconfig)

}